---
name: Color Palettes
description: Curated color palettes for Manim animations - academic, dark mode, accessible, and domain-specific schemes
tags: [manim, colors, palette, accessibility, styling, design]
---

# Color Palettes for Manim

## Why color choices matter

Color serves three purposes in mathematical animation:
1. **Semantic encoding**: "blue always means input, red always means loss" - viewers learn the vocabulary
2. **Attention direction**: bright/warm colors draw the eye; dim/cool colors recede
3. **Accessibility**: ~8% of men have color vision deficiency - your palette must work for them too

## Manim's built-in color system

Manim provides ~170 predefined color constants. Each base color has variants A (lightest) through E (darkest):

```python
BLUE_A  # lightest blue
BLUE_B
BLUE_C  # = BLUE (the default)
BLUE_D
BLUE_E  # darkest blue
```

Available bases: BLUE, RED, GREEN, YELLOW, GOLD, PURPLE, MAROON, TEAL, PINK, ORANGE, GRAY

Special: WHITE, BLACK, PURE_RED, PURE_GREEN, PURE_BLUE

Custom hex: `ManimColor("#1F77B4")`

## Recommended palettes

### Academic (light, publication-style on dark background)

Best for: conference talks, paper figures, formal presentations

```python
# style.py
PALETTE_ACADEMIC = {
    "primary": BLUE_C,        # main objects, axes
    "secondary": RED_C,       # comparison, alternative
    "accent": YELLOW_C,       # highlights, annotations
    "positive": GREEN_C,      # correct, increase, gain
    "negative": RED_D,        # error, decrease, loss
    "neutral": GRAY_B,        # labels, secondary text
    "background": BLACK,      # Manim default
}
```

### Vibrant (high contrast, 3Blue1Brown style)

Best for: YouTube, teaching videos, maximum visual impact

```python
PALETTE_VIBRANT = {
    "primary": BLUE,
    "secondary": YELLOW,
    "tertiary": GREEN,
    "highlight": PURE_YELLOW,
    "emphasis": RED,
    "subtle": GRAY,
    "background": "#1C1C1C",   # slightly lighter than pure black
}
```

### 3Blue1Brown entity-color binding (the discipline behind the look)

Frame analysis of Grant Sanderson's "Designing Math" (Config 2026) shows the rule that makes
the style legible: bind ONE color to a math entity and use that same color for BOTH the symbol
AND its geometric avatar. pi is the same red as the half-circle arc; i is the same teal
wherever it appears; the real part is yellow as a symbol and as the horizontal leg of the
vector; the imaginary part is magenta as a symbol and as the vertical leg. The viewer reads
geometry and algebra as one object because the color is shared.

```python
# Entity colors. Reuse the SAME constant for the symbol and its picture.
PI_COLOR        = "#FC6255"   # pi, and the arc it traces                     (3b1b red)
I_COLOR         = "#3FB4C9"   # i / variable z, and the rotate-90 action      (teal)
REAL_COLOR      = "#F9E04C"   # real part a, and the horizontal component     (yellow)
IMAG_COLOR      = "#E15FCB"   # imaginary part b*i / variable w, vertical leg (magenta)
PATH_COLOR      = "#83C167"   # motion / series vectors / velocity            (green)
POSITION_COLOR  = "#3FB4C9"   # position vectors                              (teal)
ACTIVE_COLOR    = "#F9E04C"   # active term, current point, swept parameter   (yellow + glow)
GRID_COLOR      = "#3C5A6E"   # background grid (low opacity)
AXIS_COLOR      = WHITE       # axes and numeric labels (kept low-emphasis)
```

Two habits that come with the binding:

1. Mark the active point with a glowing dot (a Dot plus a faint larger Dot behind it), so the
   eye always knows where "now" is.

```python
def glow_dot(point, color=ACTIVE_COLOR):
    glow = Dot(point, radius=0.18, color=color).set_opacity(0.25)
    core = Dot(point, radius=0.06, color=color)
    return VGroup(glow, core)
```

2. Color a swept parameter readout in that parameter's own color, next to the action, so the
   number and the motion are obviously the same thing.

```python
t = ValueTracker(0.0)
readout = always_redraw(lambda: MathTex(
    rf"t = {t.get_value():.2f}", color=PATH_COLOR, font_size=36
).to_corner(UL))
```


### Colorblind-safe (deuteranopia-friendly)

Best for: any public-facing content. Uses blue-orange instead of red-green.

```python
PALETTE_ACCESSIBLE = {
    "primary": "#0077BB",      # blue
    "secondary": "#EE7733",    # orange
    "tertiary": "#009988",     # teal
    "highlight": "#DDAA33",    # gold
    "negative": "#CC3311",     # vermillion (distinct from orange)
    "neutral": "#BBBBBB",      # gray
    "background": "#000000",
}
```

**Test your palette:** View your render in grayscale (desaturate in any image viewer). If you can still distinguish all elements, your palette works for most color vision deficiencies.

### ML paper palette

Best for: architecture diagrams, training curves, attention visualizations

```python
PALETTE_ML = {
    "input": GREEN_C,          # input data, embeddings
    "encoder": BLUE_C,         # encoding layers
    "decoder": PURPLE_C,       # decoding layers
    "attention": YELLOW_C,     # attention weights
    "loss": RED_C,             # loss values, errors
    "output": TEAL_C,          # predictions, output
    "label": GRAY_B,           # text labels
}
```

### Physics/Engineering palette

```python
PALETTE_PHYSICS = {
    "field": BLUE_C,           # fields, potentials
    "source": RED_C,           # sources, charges
    "detector": GREEN_C,       # detectors, measurements
    "wave": YELLOW_C,          # waves, oscillations
    "boundary": WHITE,         # boundaries, interfaces
    "annotation": GRAY_B,     # labels, dimensions
}
```

### Biomedical palette

```python
PALETTE_BIO = {
    "tissue": PINK,            # biological tissue
    "signal": GREEN_C,         # detected signals
    "source_light": RED_C,     # light sources, lasers
    "detector": BLUE_C,        # detectors, sensors
    "reconstruction": YELLOW_C, # reconstructed images
    "reference": GRAY_B,       # reference, baseline
}
```

## Named palette presets

These four palettes cover most use cases out of the box. Copy whichever fits your
project into `style.py` and rename keys to match your domain vocabulary.

### Classic 3B1B

The Grant Sanderson signature look. High-contrast primaries on a deep navy background.

```python
PALETTE_3B1B = {
    "primary": BLUE_C,
    "secondary": GREEN_C,
    "accent": YELLOW,
    "highlight": GOLD,
    "negative": RED_C,
    "dim": GREY_B,
    "bg": "#1a1a2e",
}
```

### Warm Academic

Muted, publication-friendly tones with warm accents. Good for formal talks where
the vibrant palette feels too loud.

```python
PALETTE_ACADEMIC_WARM = {
    "primary": "#2E86AB",
    "secondary": "#A23B72",
    "accent": "#F18F01",
    "highlight": "#C73E1D",
    "negative": "#592E83",
    "dim": "#8B8B8B",
    "bg": "#1C1C1C",
}
```

### Neon Tech

High-energy palette for tech demos, algorithm visualizations, and anything that
should feel modern and electric.

```python
PALETTE_NEON = {
    "primary": "#00F5FF",
    "secondary": "#FF006E",
    "accent": "#FFBE0B",
    "highlight": "#8338EC",
    "negative": "#FB5607",
    "dim": "#555555",
    "bg": "#0D0D0D",
}
```

### Monochrome

Minimalist grayscale with a single accent color. Forces you to communicate
through shape, motion, and layout instead of color.

```python
PALETTE_MONO = {
    "primary": WHITE,
    "secondary": GREY_A,
    "accent": YELLOW,
    "highlight": WHITE,
    "negative": GREY_C,
    "dim": GREY_D,
    "bg": BLACK,
}
```

**Usage:** copy a preset into your `style.py`, then rename keys to semantic names
for your domain. For example, in a neural network video you might rename
`"primary"` to `"weights"` and `"negative"` to `"loss"`. The point is consistency
across all your scenes, not the specific key names.

## How to use a palette consistently

Create a `style.py` file and import it in every scene:

```python
# style.py
from manim import *

# Choose your palette
C = {
    "primary": BLUE_C,
    "secondary": RED_C,
    "accent": YELLOW_C,
    "positive": GREEN_C,
    "negative": RED_D,
    "dim": GRAY,
}

TITLE_SIZE = 64
BODY_SIZE = 40
LABEL_SIZE = 28
```

```python
# scenes/s01_intro.py
from manim import *
from style import C, TITLE_SIZE

class Intro(Scene):
    def construct(self):
        title = Text("My Paper", font_size=TITLE_SIZE, color=C["primary"])
        # ...
```

## Color operations

```python
from manim.utils.color import interpolate_color, color_gradient

# Blend two colors
mid = interpolate_color(RED, BLUE, 0.5)  # alpha=0.5 = halfway

# Create a gradient (list of N colors from start to end)
gradient = color_gradient([BLUE, GREEN, YELLOW], 10)  # 10 colors

# Set a gradient on a mobject
mob.set_color_by_gradient(BLUE, RED)  # left-to-right gradient

# Height-based coloring for 3D surfaces
surface.set_fill_by_value(
    axes,
    colorscale=[(RED, -1), (YELLOW, 0), (GREEN, 1)],
    axis=2,  # z-axis
)
```

## Anti-patterns

1. **Using red and green together** for important distinctions - 8% of viewers cannot tell them apart
2. **Too many colors** in one scene - limit to 4-5 distinct colors max
3. **Changing a color's meaning** between scenes - if blue means "input" in scene 1, keep it
4. **Pure white on pure black** for large areas - it creates harsh contrast. Use GRAY_B for labels
5. **Neon/saturated colors for large fills** - use lower opacity (0.3-0.5) for fills, full saturation for strokes only
