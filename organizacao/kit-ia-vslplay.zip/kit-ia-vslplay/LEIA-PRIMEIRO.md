# Kit para a IA do VSL Play

Comece por organizacao/COLABORACAO-AGENTICA-VITOR.md, depois COLABORACAO-AGENTICA-VSLPLAY.md e COLABORACAO-AGENTICA-VSLPLAY-CONTEUDO.md.
O resto são os arquivos que esses guias citam: regras de gosto (motion-base/DESIGN-SYSTEM.md), lições (motion-base/LICOES-MOTION.md),
o motor de vídeo (estudio/), o anúncio 10/10 da VSL Play (anuncio-vslplay/BRIEF.md e SPEC.md) e as skills (.claude/skills/).
Copie a pasta .claude/skills para dentro do projeto novo para ter as skills.
O código completo do motor e das peças está no GitHub vodetmor/edicao-de-video-claude-vodetmor. Nenhuma chave está neste kit.
