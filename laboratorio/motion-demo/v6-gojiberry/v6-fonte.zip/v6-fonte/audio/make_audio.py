"""Soundtrack + SFX, 100% synthesized with numpy (no samples, no licensing).

96 BPM -> 1 bar = 2.5 s = 75 frames, so every scene cut in Benchmark.tsx lands on a downbeat.
Run: python3 audio/make_audio.py  -> public/mix.wav (and stems in audio/)
"""
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
import os

SR = 48000
DUR = 30.0
N = int(SR * DUR)
FPS = 30
BEAT = 60 / 96
BAR = BEAT * 4
rng = np.random.default_rng(7)
HERE = os.path.dirname(os.path.abspath(__file__))


def f2s(frame):  # video frame -> seconds
    return frame / FPS


def buf():
    return np.zeros((N, 2))


def place(dst, sig, t, gain=1.0, pan=0.0):
    i = int(t * SR)
    if i >= N:
        return
    sig = sig[: N - i]
    l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    dst[i : i + len(sig), 0] += sig * gain * l * 1.414
    dst[i : i + len(sig), 1] += sig * gain * r * 1.414


def env(n, a, d):
    t = np.arange(n) / SR
    e = np.minimum(t / max(a, 1e-4), 1) * np.exp(-t / d)
    return e


def lp(x, fc, order=2):
    return sosfilt(butter(order, fc, 'low', fs=SR, output='sos'), x)


def hp(x, fc, order=2):
    return sosfilt(butter(order, fc, 'high', fs=SR, output='sos'), x)


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], 'band', fs=SR, output='sos'), x)


def midi(m):
    return 440 * 2 ** ((m - 69) / 12)


# ---------------- instruments ----------------
def kick(d=0.45):
    n = int(SR * d)
    t = np.arange(n) / SR
    f = 45 + 110 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t / 0.16) + 0.15 * lp(rng.standard_normal(n), 3000) * np.exp(-t / 0.004)


def hat(d=0.06):
    n = int(SR * d)
    return hp(rng.standard_normal(n), 8000) * env(n, 0.0005, 0.018)


def clap():
    n = int(SR * 0.25)
    x = bp(rng.standard_normal(n), 900, 4000)
    e = np.zeros(n)
    for k, o in enumerate([0, 0.009, 0.018]):
        i = int(o * SR)
        e[i:] += env(n - i, 0.0005, 0.012 if k < 2 else 0.07)
    return x * e * 0.8


def pluck(freq, d=0.6):
    # Karplus-Strong
    n = int(SR * d)
    p = int(SR / freq)
    b = rng.uniform(-1, 1, p)
    out = np.zeros(n)
    for i in range(n):
        out[i] = b[i % p]
        b[i % p] = 0.5 * (b[i % p] + b[(i + 1) % p]) * 0.996
    return lp(out, 5000) * env(n, 0.002, 0.35)


def pad_note(freq, d):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for det in (-0.004, 0, 0.005):
        f = freq * (1 + det)
        x += np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 3 * f * t)
    a = np.minimum(t / 0.5, 1) * np.minimum((d - t) / 0.4, 1)
    return x * np.clip(a, 0, 1) / 3


def bass_note(freq, d):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * freq * t) + 0.25 * np.sin(2 * np.pi * 2 * freq * t)
    return lp(x, 600) * env(n, 0.005, 0.22)


def bell(freq, d=2.5):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * freq * t) * np.exp(-t / 0.9)
    x += 0.4 * np.sin(2 * np.pi * freq * 2.76 * t) * np.exp(-t / 0.35)
    x += 0.2 * np.sin(2 * np.pi * freq * 5.4 * t) * np.exp(-t / 0.15)
    return x * np.minimum(t / 0.002, 1)


# ---------------- SFX ----------------
def whoosh(d=0.45, up=True):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = rng.standard_normal(n)
    out = np.zeros(n)
    blk = 512
    for i in range(0, n, blk):
        k = i / n
        fc = 300 + (4500 if up else 4500 * (1 - k)) * (k if up else 1)
        out[i : i + blk] = bp(x[max(0, i - 2048) : i + blk], fc * 0.6, min(fc * 1.6, 20000))[-len(x[i : i + blk]) :]
    e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2
    return out * e * 0.6


def tick():
    n = int(SR * 0.03)
    t = np.arange(n) / SR
    return np.sin(2 * np.pi * 2400 * t) * env(n, 0.0003, 0.006)


def pop(freq=880):
    n = int(SR * 0.18)
    t = np.arange(n) / SR
    f = freq * (1 + 0.6 * np.exp(-t / 0.01))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, 0.001, 0.05)


def riser(d):
    n = int(SR * d)
    t = np.arange(n) / SR
    k = t / d
    x = rng.standard_normal(n)
    out = np.zeros(n)
    blk = 1024
    for i in range(0, n, blk):
        fc = 200 + 7000 * (i / n) ** 2
        seg = bp(x[max(0, i - 4096) : i + blk], fc * 0.7, min(fc * 1.4, 20000))
        out[i : i + blk] = seg[-len(x[i : i + blk]) :]
    tone = np.sin(2 * np.pi * np.cumsum(110 + 330 * k**2) / SR) * 0.3
    return (out + tone) * k**2.2


def impact():
    n = int(SR * 2.2)
    t = np.arange(n) / SR
    sub = np.sin(2 * np.pi * np.cumsum(38 + 60 * np.exp(-t / 0.06)) / SR) * np.exp(-t / 0.7)
    noise = lp(rng.standard_normal(n), 2500) * np.exp(-t / 0.12) * 0.35
    return sub + noise


# ---------------- arrangement ----------------
music, drums, sfx = buf(), buf(), buf()

# F - C/E - Am - G (x3)
CHORDS = [
    [53, 57, 60, 64],  # Fmaj7
    [52, 55, 60, 67],  # C/E
    [57, 60, 64, 67],  # Am7
    [55, 59, 62, 67],  # G
]
ROOTS = [41, 40, 45, 43]
TIE0, TIE1 = f2s(525), f2s(600)

for bar in range(12):
    t0 = bar * BAR
    ch = CHORDS[bar % 4]
    last = bar == 11
    if last:
        ch = [53, 57, 60, 64, 69]
    in_tie = TIE0 <= t0 < TIE1
    for m in ch:
        place(music, pad_note(midi(m), BAR + 0.4), t0, 0.07 if not in_tie else 0.03)
    # arp from bar 1
    if bar >= 1 and not in_tie and not last:
        seq = ch + [ch[1] + 12, ch[2] + 12, ch[3] + 12, ch[2] + 12]
        for s in range(8):
            place(music, pluck(midi(seq[s] + 12)), t0 + s * BEAT / 2, 0.22 if s % 2 == 0 else 0.14, pan=-0.35 if s % 2 else 0.35)
    # bass from bar 3
    if bar >= 3 and not in_tie and bar < 11:
        for s in range(8):
            if s % 2 == 1 or s == 0:
                place(music, bass_note(midi(ROOTS[bar % 4]), 0.3), t0 + s * BEAT / 2, 0.55)
    # drums
    for b in range(4):
        tb = t0 + b * BEAT
        if in_tie or last:
            continue
        if bar >= 3 or (bar == 2 and b >= 2):
            place(drums, kick(), tb, 0.9)
        if bar >= 3:
            place(drums, hat(), tb + BEAT / 2, 0.18, pan=0.2)
        if bar >= 4 and b in (1, 3):
            place(drums, clap(), tb, 0.35, pan=-0.1)
    if bar == 10:  # outro first bar: half-time
        pass

# sidechain the music on kicks
side = np.ones(N)
for bar in range(12):
    for b in range(4):
        tb = bar * BAR + b * BEAT
        if (TIE0 <= tb < TIE1) or bar >= 11 or bar < 3:
            continue
        i = int(tb * SR)
        L = int(0.25 * SR)
        side[i : i + L] = np.minimum(side[i : i + L], 1 - 0.45 * np.exp(-np.arange(min(L, N - i)) / SR / 0.08))
music *= side[:, None]

# ---- SFX synced to Benchmark.tsx ----
# intro text
place(sfx, pop(1320), f2s(2), 0.18)
place(sfx, pop(990), f2s(18), 0.18)
# scene cuts
for fr in (75 - 8, 225 - 8, 300 - 6, 375 - 6, 450 - 6, 600 - 6, 750 - 6):
    place(sfx, whoosh(0.4), f2s(fr), 0.35, pan=0.3)
# logos
place(sfx, bell(midi(76)), f2s(75 + 8), 0.12, pan=-0.4)
place(sfx, bell(midi(79)), f2s(75 + 16), 0.12, pan=0.4)
place(sfx, pop(660), f2s(75 + 30), 0.3)
# benchmark cards: counting ticks, then winner pop
for c in range(4):
    base = 225 + c * 75
    for k, fr in enumerate(range(10, 44, 2)):
        place(sfx, tick(), f2s(base + fr), 0.10 * (1 - k / 20), pan=(-0.3 if k % 2 else 0.3))
    place(sfx, pop(1175), f2s(base + 44), 0.35)
    place(sfx, bell(midi(88), 0.8), f2s(base + 44), 0.05)
# tie: riser into black, impact on "Empate."
place(sfx, riser(1.8), TIE0 - 1.8, 0.35)
place(sfx, impact(), TIE0, 0.55)
for k, fr in enumerate(range(4, 30, 2)):
    place(sfx, tick(), f2s(525 + fr), 0.09)
place(sfx, impact(), f2s(525 + 34), 0.8)
place(sfx, bell(midi(69), 3), f2s(525 + 34), 0.12)
# price
place(sfx, pop(880), f2s(600 + 2), 0.2)
place(sfx, pop(990), f2s(600 + 66), 0.2)
for k, fr in enumerate(range(84, 116, 2)):
    place(sfx, tick(), f2s(600 + fr), 0.08)
# outro
place(sfx, pop(784), f2s(750 + 28), 0.18)
for k, m in enumerate([72, 76, 79, 84]):
    place(sfx, bell(midi(m), 3), f2s(750 + 84) + k * 0.09, 0.09, pan=-0.3 + 0.2 * k)

mix = 0.9 * music + 0.8 * drums + 1.0 * sfx
# gentle master: fade out, soft clip, normalize to -1 dBFS
t = np.arange(N) / SR
mix *= np.clip((DUR - t) / 1.2, 0, 1)[:, None]
mix = np.tanh(mix * 1.0)
mix *= 10 ** (-1 / 20) / np.max(np.abs(mix))

os.makedirs(os.path.join(HERE, '..', 'public'), exist_ok=True)
wavfile.write(os.path.join(HERE, '..', 'public', 'mix.wav'), SR, (mix * 32767).astype(np.int16))
for name, s in (('music', music), ('drums', drums), ('sfx', sfx)):
    s = s / (np.max(np.abs(s)) + 1e-9) * 0.9
    wavfile.write(os.path.join(HERE, f'stem-{name}.wav'), SR, (s * 32767).astype(np.int16))
print('ok')
