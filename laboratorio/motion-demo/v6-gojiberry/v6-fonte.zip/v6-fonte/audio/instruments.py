"""Soundtrack + SFX, 100% synthesized with numpy (no samples, no licensing).

96 BPM -> 1 bar = 2.5 s = 75 frames, so every scene cut in Benchmark.tsx lands on a downbeat.
Run: python3 audio/make_audio.py  -> public/mix.wav (and stems in audio/)
"""
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
import os

SR = 48000
DUR = 30.0
N = int(SR * DUR)
FPS = 30
BEAT = 60 / 96
BAR = BEAT * 4
rng = np.random.default_rng(7)
HERE = os.path.dirname(os.path.abspath(__file__))


def f2s(frame):  # video frame -> seconds
    return frame / FPS


def buf():
    return np.zeros((N, 2))


def place(dst, sig, t, gain=1.0, pan=0.0):
    i = int(t * SR)
    if i >= N:
        return
    sig = sig[: N - i]
    l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    dst[i : i + len(sig), 0] += sig * gain * l * 1.414
    dst[i : i + len(sig), 1] += sig * gain * r * 1.414


def env(n, a, d):
    t = np.arange(n) / SR
    e = np.minimum(t / max(a, 1e-4), 1) * np.exp(-t / d)
    return e


def lp(x, fc, order=2):
    return sosfilt(butter(order, fc, 'low', fs=SR, output='sos'), x)


def hp(x, fc, order=2):
    return sosfilt(butter(order, fc, 'high', fs=SR, output='sos'), x)


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], 'band', fs=SR, output='sos'), x)


def midi(m):
    return 440 * 2 ** ((m - 69) / 12)


# ---------------- instruments ----------------
def kick(d=0.45):
    n = int(SR * d)
    t = np.arange(n) / SR
    f = 45 + 110 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t / 0.16) + 0.15 * lp(rng.standard_normal(n), 3000) * np.exp(-t / 0.004)


def hat(d=0.06):
    n = int(SR * d)
    return hp(rng.standard_normal(n), 8000) * env(n, 0.0005, 0.018)


def clap():
    n = int(SR * 0.25)
    x = bp(rng.standard_normal(n), 900, 4000)
    e = np.zeros(n)
    for k, o in enumerate([0, 0.009, 0.018]):
        i = int(o * SR)
        e[i:] += env(n - i, 0.0005, 0.012 if k < 2 else 0.07)
    return x * e * 0.8


def pluck(freq, d=0.6):
    # Karplus-Strong
    n = int(SR * d)
    p = int(SR / freq)
    b = rng.uniform(-1, 1, p)
    out = np.zeros(n)
    for i in range(n):
        out[i] = b[i % p]
        b[i % p] = 0.5 * (b[i % p] + b[(i + 1) % p]) * 0.996
    return lp(out, 5000) * env(n, 0.002, 0.35)


def pad_note(freq, d):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for det in (-0.004, 0, 0.005):
        f = freq * (1 + det)
        x += np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 3 * f * t)
    a = np.minimum(t / 0.5, 1) * np.minimum((d - t) / 0.4, 1)
    return x * np.clip(a, 0, 1) / 3


def bass_note(freq, d):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * freq * t) + 0.25 * np.sin(2 * np.pi * 2 * freq * t)
    return lp(x, 600) * env(n, 0.005, 0.22)


def bell(freq, d=2.5):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * freq * t) * np.exp(-t / 0.9)
    x += 0.4 * np.sin(2 * np.pi * freq * 2.76 * t) * np.exp(-t / 0.35)
    x += 0.2 * np.sin(2 * np.pi * freq * 5.4 * t) * np.exp(-t / 0.15)
    return x * np.minimum(t / 0.002, 1)


# ---------------- SFX ----------------
def whoosh(d=0.45, up=True):
    n = int(SR * d)
    t = np.arange(n) / SR
    x = rng.standard_normal(n)
    out = np.zeros(n)
    blk = 512
    for i in range(0, n, blk):
        k = i / n
        fc = 300 + (4500 if up else 4500 * (1 - k)) * (k if up else 1)
        out[i : i + blk] = bp(x[max(0, i - 2048) : i + blk], fc * 0.6, min(fc * 1.6, 20000))[-len(x[i : i + blk]) :]
    e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2
    return out * e * 0.6


def tick():
    n = int(SR * 0.03)
    t = np.arange(n) / SR
    return np.sin(2 * np.pi * 2400 * t) * env(n, 0.0003, 0.006)


def pop(freq=880):
    n = int(SR * 0.18)
    t = np.arange(n) / SR
    f = freq * (1 + 0.6 * np.exp(-t / 0.01))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, 0.001, 0.05)


def riser(d):
    n = int(SR * d)
    t = np.arange(n) / SR
    k = t / d
    x = rng.standard_normal(n)
    out = np.zeros(n)
    blk = 1024
    for i in range(0, n, blk):
        fc = 200 + 7000 * (i / n) ** 2
        seg = bp(x[max(0, i - 4096) : i + blk], fc * 0.7, min(fc * 1.4, 20000))
        out[i : i + blk] = seg[-len(x[i : i + blk]) :]
    tone = np.sin(2 * np.pi * np.cumsum(110 + 330 * k**2) / SR) * 0.3
    return (out + tone) * k**2.2


def impact():
    n = int(SR * 2.2)
    t = np.arange(n) / SR
    sub = np.sin(2 * np.pi * np.cumsum(38 + 60 * np.exp(-t / 0.06)) / SR) * np.exp(-t / 0.7)
    noise = lp(rng.standard_normal(n), 2500) * np.exp(-t / 0.12) * 0.35
    return sub + noise


