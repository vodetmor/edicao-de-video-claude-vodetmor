"""v6 soundtrack + SFX (all synthesized). Every hit sits on the frame of its visual action (24 fps),
using the shot timings from SPEC.md. Music at 125 BPM (the reference's pulse). Master -14 LUFS.
Run: python3 audio/make_audio_v6.py -> public/v6-mix.wav
"""
import os, subprocess, re
import numpy as np
from scipy.io import wavfile
from instruments import *  # noqa: F401,F403  (SR, N, place, kick, hat, clap, pluck, pad_note, bass_note, bell, whoosh, tick, pop, riser, impact, lp, hp, bp, env, midi, rng)

HERE = os.path.dirname(os.path.abspath(__file__))
FPS = 24


def fr(f):
    return f / FPS


BPM = 125.0
BEAT = 60 / BPM
BAR = BEAT * 4


def click():
    n = int(SR * 0.05)
    t = np.arange(n) / SR
    body = np.sin(2 * np.pi * 1800 * t) * np.exp(-t / 0.004)
    noise = hp(rng.standard_normal(n), 3000) * np.exp(-t / 0.003)
    return 0.6 * body + 0.5 * noise


def key():  # keyboard tap
    n = int(SR * 0.04)
    t = np.arange(n) / SR
    return bp(rng.standard_normal(n), 1500, 6000) * np.exp(-t / 0.006) * 0.8


def crackle(d=0.6, density=180):  # pixel burst: many tiny grains
    n = int(SR * d)
    out = np.zeros(n)
    for i in range(int(density * d)):
        at = int((i / (density * d)) ** 1.8 * n)
        g = key() * (1 - at / n)
        out[at : at + len(g)] += g[: n - at] * rng.uniform(0.3, 1)
    return out


def sub_hit():
    n = int(SR * 1.2)
    t = np.arange(n) / SR
    return np.sin(2 * np.pi * np.cumsum(42 + 70 * np.exp(-t / 0.05)) / SR) * np.exp(-t / 0.45)


music, drums, sfx = buf(), buf(), buf()

# ---------------- music ----------------
CHORDS = [[53, 57, 60, 64], [52, 55, 60, 67], [57, 60, 64, 67], [55, 59, 62, 67]]  # Fmaj7 C/E Am7 G
ROOTS = [41, 40, 45, 43]
nbars = int(30 / BAR) + 1


def section(t):
    if t < 4.25:
        return 'intro'
    if t < 9.0:
        return 'build'
    if t < 18.8:
        return 'drive'
    if t < fr(470):
        return 'lift'
    if t < 26.0:
        return 'full'
    if t < fr(686):
        return 'break'
    return 'end'


for b in range(nbars):
    t0 = b * BAR
    if t0 >= 30:
        break
    ch = CHORDS[b % 4]
    sec = section(t0)
    for m in ch:
        place(music, pad_note(midi(m), BAR + 0.3), t0, 0.06 if sec != 'end' else 0.08)
    for s in range(8):
        ts = t0 + s * BEAT / 2
        sc = section(ts)
        if ts >= 30:
            break
        seq = ch + [ch[1] + 12, ch[2] + 12, ch[3] + 12, ch[2] + 12]
        if sc in ('intro',) and s % 2:
            continue
        if sc != 'end':
            place(music, pluck(midi(seq[s] + 12), 0.5), ts, 0.16 if sc == 'intro' else 0.2, pan=-0.35 if s % 2 else 0.35)
        if sc in ('drive', 'full', 'lift') and (s % 2 == 1 or s == 0):
            place(music, bass_note(midi(ROOTS[b % 4]), 0.25), ts, 0.5)
        if sc in ('build', 'drive', 'full', 'lift'):
            place(drums, hat(), ts + BEAT / 4, 0.14 if sc == 'build' else 0.2, pan=0.2)
    for k in range(4):
        tb = t0 + k * BEAT
        sc = section(tb)
        if sc in ('drive', 'full'):
            place(drums, kick(), tb, 0.85)
        if sc == 'full' and k in (1, 3):
            place(drums, clap(), tb, 0.3, pan=-0.1)

# final chord on the last hard cut
for m in [53, 57, 60, 64, 69]:
    place(music, pad_note(midi(m), 1.6), fr(686), 0.09)

# ---------------- SFX on the visual frames ----------------
# S1 lockup: letters, Claude mark pop, colour settle
for f in range(1, 12):
    place(sfx, key(), fr(f), 0.12)
place(sfx, pop(990), fr(11), 0.3)
for f in range(17, 26):
    place(sfx, key(), fr(f), 0.12)
place(sfx, bell(midi(81), 1.2), fr(24), 0.06)
# S2 prompt
place(sfx, impact(), fr(38), 0.25)
place(sfx, pop(1320), fr(38), 0.25)
place(sfx, whoosh(0.3), fr(46) - 0.15, 0.5, pan=0.3)
place(sfx, click(), fr(66.5), 0.9)
for i, f in enumerate(np.arange(72, 92, 1.3)):
    place(sfx, key(), fr(f), 0.22, pan=(-0.2 if i % 2 else 0.2))
# S3 icon + wordmark + delete
place(sfx, pop(700), fr(102), 0.45)
for i in range(9):
    place(sfx, key(), fr(108 + i * 1.2), 0.2)
for i in range(9):
    t = (i / 9) ** 0.5 * 10
    place(sfx, key(), fr(128 + t), 0.16)
place(sfx, pop(520), fr(135), 0.3)
# S4 tile morph + iris
place(sfx, bell(midi(76), 1.4), fr(142), 0.08)
place(sfx, riser(0.6), fr(160) - 0.3, 0.18)
place(sfx, crackle(0.5, 120), fr(160), 0.22)
place(sfx, whoosh(0.45), fr(163), 0.35)
# S5 window
for i in range(6):
    place(sfx, tick(), fr(176 + i * 3), 0.1)
place(sfx, whoosh(0.5), fr(194) - 0.1, 0.45)
# S6 typing
for i in range(7):
    place(sfx, key(), fr(216 + i * 3), 0.3, pan=0.15)
place(sfx, whoosh(0.35), fr(244), 0.3, pan=-0.3)
WORDS = [248, 254, 258, 266, 270, 274, 316, 319, 324, 327, 364, 370, 373, 402, 412, 417]
for i, f in enumerate(WORDS):
    place(sfx, key(), fr(f), 0.55, pan=(-0.25 if i % 2 else 0.25))
    place(sfx, pop(1400 + 80 * (i % 5)), fr(f), 0.14)
for f in (312, 360, 398):
    place(sfx, whoosh(0.3), fr(f), 0.3)
# S7 send + click + burst
place(sfx, pop(880), fr(452), 1.3)
place(sfx, click(), fr(452), 1.0)
place(sfx, impact(), fr(452), 0.3)
place(sfx, riser(0.6), fr(456), 0.12)
place(sfx, click(), fr(469.5), 1.0)
place(sfx, impact(), fr(470), 0.55)
place(sfx, crackle(0.7, 220), fr(471), 0.35)
place(sfx, whoosh(0.4), fr(476), 0.35)
# S9 bubble + Analisando + whip
place(sfx, whoosh(0.3), fr(484), 0.35)
place(sfx, pop(760), fr(486), 0.5)
place(sfx, bell(midi(84), 0.8), fr(500), 0.05)
place(sfx, riser(0.5), fr(516), 0.15)
place(sfx, whoosh(0.3), fr(522), 0.35)
place(sfx, impact(), fr(528.5), 0.7)
# S11 tiles + centre tile
for i in range(8):
    place(sfx, pop(700 + 90 * i), fr(526 + i), 0.18, pan=-0.5 + i / 7)
place(sfx, sub_hit(), fr(535), 0.6)
place(sfx, impact(), fr(535), 0.8)
place(sfx, click(), fr(535), 0.8)
place(sfx, pop(620), fr(535), 0.7)
for i in range(8):
    place(sfx, tick(), fr(548 + i * 3), 0.1)
place(sfx, whoosh(0.4), fr(556), 0.35)
place(sfx, pop(990), fr(564), 0.45)
place(sfx, whoosh(0.4), fr(568) - 0.15, 0.3)
place(sfx, pop(700), fr(568), 0.6)
place(sfx, pop(620), fr(586), 0.5)
place(sfx, click(), fr(586), 0.5)
# S13 card lines + exit
for i in range(7):
    place(sfx, key(), fr(586 + i * 2), 0.45)
    place(sfx, pop(1200 + 60 * i), fr(586 + i * 2), 0.1)
place(sfx, whoosh(0.4), fr(609), 0.45, pan=-0.4)
# S14 tagline words + whip
for i, f in enumerate([618, 620, 623, 626, 629, 631, 633]):
    place(sfx, key(), fr(f), 0.5)
    place(sfx, pop(1500 + 40 * i), fr(f), 0.1)
place(sfx, bell(midi(79), 1.5), fr(634), 0.08)
place(sfx, key(), fr(639), 0.45)
place(sfx, pop(1180), fr(639), 0.25)
place(sfx, riser(0.4), fr(676) - 0.2, 0.3)
place(sfx, impact(), fr(676), 0.35)
place(sfx, whoosh(0.35), fr(676), 0.5, pan=-0.5)
# S15 end
place(sfx, impact(), fr(686), 0.55)
for k, m in enumerate([72, 76, 79, 84]):
    place(sfx, bell(midi(m), 2.5), fr(686) + k * 0.07, 0.07, pan=-0.3 + 0.2 * k)
place(sfx, whoosh(0.3), fr(692), 0.2)
place(sfx, click(), fr(707), 1.4)
place(sfx, pop(990), fr(707), 0.6)
place(sfx, bell(midi(88), 1.2), fr(708), 0.08)
place(sfx, tick(), fr(701), 0.6)
place(sfx, key(), fr(701), 0.6)
place(sfx, pop(1320), fr(715), 0.6)

# ---------------- mix + master ----------------
side = np.ones(N)
for b in range(nbars):
    for k in range(4):
        tb = b * BAR + k * BEAT
        if section(tb) in ('drive', 'full') and tb < 30:
            i = int(tb * SR)
            L = min(int(0.2 * SR), N - i)
            if L > 0:
                side[i : i + L] = np.minimum(side[i : i + L], 1 - 0.4 * np.exp(-np.arange(L) / SR / 0.07))
music *= side[:, None]
mix = 0.7 * music + 0.62 * drums + 1.0 * sfx
t = np.arange(N) / SR
mix *= np.clip((30 - t) / 0.2, 0, 1)[:, None]

ff = os.environ.get('FFMPEG', 'ffmpeg')
out = os.path.join(HERE, '..', 'public', 'v6-mix.wav')


def write(x):
    wavfile.write(out, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))


def lufs():
    r = subprocess.run([ff, '-hide_banner', '-i', out, '-af', 'ebur128=framelog=quiet', '-f', 'null', '-'], capture_output=True, text=True)
    return float(re.findall(r'I:\s+(-?[\d.]+) LUFS', r.stderr)[-1])


x = np.tanh(mix / (np.max(np.abs(mix)) + 1e-9) * 1.4)
for _ in range(3):
    write(x * 0.89)
    gain = 10 ** ((-14.0 - lufs()) / 20)
    x = np.tanh(x * gain * 1.0)
write(x * min(0.89, 0.89 / (np.max(np.abs(x)) + 1e-9)))
print('LUFS', lufs())
