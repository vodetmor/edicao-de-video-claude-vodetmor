# Benchmark v6 (estilo Gojiberry) — Remotion + áudio sintetizado

- Estudo da referência: /mnt/project-files/motion-base/estudos/gojiberry/SPEC.md
- Regras: /mnt/project-files/motion-base/LICOES-MOTION.md

## Rodar
    npm i
    python3 audio/make_audio_v6.py          # gera public/v6-mix.wav (-14 LUFS); precisa numpy, scipy, ffmpeg
    npx remotion studio                      # composição "V6" (1920x1080, 24 fps, 30 s)
    npx remotion render src/index.ts V6 out/v6-video.mp4 --muted --props='{"withAudio":false}'
    ffmpeg -i out/v6-video.mp4 -i public/v6-mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -shortest out/v6.mp4

O mux do áudio é feito no ffmpeg de propósito: o mux do Remotion atrasava o áudio ~1 frame.
