import React from 'react';
import {staticFile} from 'remotion';
import {CLAUDE_PATHS, OPENAI_PATHS} from '../logos';

// Visual rules (locked, see motion-base/estudos/gojiberry/SPEC.md)
export const C = {
  bg: '#FFFFFF',
  ink: '#1D1D1F',
  gray: '#86868B',
  line: '#E5E5EA',
  soft: '#F2F2F4',
  accent: '#D97757',
  white: '#FFFFFF',
};
export const FONT = 'InterLocal';
export const fontCss = [400, 500, 600, 700, 800]
  .map(
    (w) =>
      `@font-face{font-family:${FONT};font-weight:${w};src:url(${staticFile(
        `inter-latin-${w}-normal.woff2`,
      )}) format('woff2');}`,
  )
  .join('');

export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

// "Arrive fast, land soft": a fixed fraction k of the remaining distance per frame.
// Measured on the reference: k ~ 0.25 at 24 fps.
export const approach = (f: number, start: number, from: number, to: number, k = 0.25) =>
  f <= start ? from : to - (to - from) * Math.pow(1 - k, f - start);

// Exits accelerate (ease-in, cubic), measured on the reference card/wordmark exits.
export const easeIn = (f: number, start: number, dur: number, from: number, to: number) => {
  const t = clamp01((f - start) / dur);
  return from + (to - from) * t * t * t;
};

// 0..1 progress with the same approach curve (for opacity/blur/colour)
export const arrive = (f: number, start: number, k = 0.25) => approach(f, start, 0, 1, k);

// Directional motion blur (SVG filter). Horizontal or vertical only, like the reference.
export const DirBlur: React.FC<{x?: number; y?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({
  x = 0,
  y = 0,
  children,
  style,
}) => {
  const id = 'db' + React.useId().replace(/[^a-zA-Z0-9]/g, '');
  const on = x > 0.3 || y > 0.3;
  return (
    <div style={{...style, filter: on ? `url(#${id})` : undefined}}>
      {on && (
        <svg width={0} height={0} style={{position: 'absolute'}}>
          <filter id={id} x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation={`${x.toFixed(2)} ${y.toFixed(2)}`} />
          </filter>
        </svg>
      )}
      {children}
    </div>
  );
};

export const OpenAIMark: React.FC<{size: number; color?: string}> = ({size, color = C.ink}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{display: 'block'}}>
    {OPENAI_PATHS.map((d, i) => (
      <path key={i} d={d} fill={color} fillRule="evenodd" />
    ))}
  </svg>
);

export const ClaudeMark: React.FC<{size: number; color?: string}> = ({size, color = C.accent}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{display: 'block'}}>
    {CLAUDE_PATHS.map((d, i) => (
      <path key={i} d={d} fill={color} />
    ))}
  </svg>
);

export const Cursor: React.FC<{x: number; y: number; press?: number; opacity?: number}> = ({x, y, press = 0, opacity = 1}) => (
  <svg
    width={56}
    height={56}
    viewBox="0 0 24 24"
    style={{position: 'absolute', left: x, top: y, transform: `scale(${1 - 0.15 * press})`, transformOrigin: '4px 3px', opacity}}
  >
    <path d="M4 3 L4 19.5 L8.4 15.4 L11.3 21.6 L14 20.4 L11.2 14.3 L17.2 14.1 Z" fill={C.ink} stroke={C.white} strokeWidth={1.4} strokeLinejoin="round" />
  </svg>
);

// deterministic hash for pixel/dot fields
export const hash = (i: number, s = 0) => {
  let n = (i * 374761393 + s * 668265263) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
};

// Typed text, word by word: each word blurs in and lands (approach), coloured words keep their colour.
export type Word = {t: string; at: number; color?: string; weight?: number};
export const TypedWords: React.FC<{f: number; words: Word[]; size: number; gap?: number; style?: React.CSSProperties}> = ({
  f,
  words,
  size,
  gap = 0.28,
  style,
}) => (
  <div style={{display: 'flex', whiteSpace: 'nowrap', alignItems: 'baseline', ...style}}>
    {words.map((w, i) => {
      const p = arrive(f, w.at, 0.3);
      const vis = f >= w.at;
      return (
        <span
          key={i}
          style={{
            display: 'inline-block',
            marginRight: `${gap}em`,
            fontSize: size,
            fontWeight: w.weight ?? 500,
            letterSpacing: '-0.03em',
            color: w.color ?? C.ink,
            opacity: vis ? p : 0,
            transform: `translateX(${(1 - p) * size * 0.35}px)`,
            filter: vis && p < 0.97 ? `blur(${((1 - p) * size) / 14}px)` : undefined,
          }}
        >
          {w.t}
        </span>
      );
    })}
  </div>
);
