import React from 'react';
import {AbsoluteFill, interpolate, interpolateColors} from 'remotion';
import {
  C,
  ClaudeMark,
  Cursor,
  DirBlur,
  OpenAIMark,
  TypedWords,
  Word,
  approach,
  arrive,
  clamp01,
  easeIn,
  hash,
} from './kit';

// All frame numbers are absolute (24 fps) and match SPEC.md shot by shot.
type P = {f: number};
const W = 1920;
const H = 1080;

// Letters of a word typed one by one (with blur), optional right-to-left delete.
const TypeLetters: React.FC<{
  f: number;
  text: string;
  start: number;
  per: number;
  size: number;
  color: string;
  weight?: number;
  delStart?: number;
  delDur?: number;
}> = ({f, text, start, per, size, color, weight = 600, delStart, delDur = 12}) => {
  const chars = text.split('');
  let keep = chars.length;
  if (delStart !== undefined && f >= delStart) {
    const t = clamp01((f - delStart) / delDur);
    keep = Math.round(chars.length * (1 - t * t)); // accelerating delete (ease-in)
  }
  return (
    <span style={{display: 'inline-flex', fontSize: size, fontWeight: weight, letterSpacing: '-0.035em', color}}>
      {chars.slice(0, keep).map((c, i) => {
        const at = start + i * per;
        const p = arrive(f, at, 0.3);
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              whiteSpace: 'pre',
              opacity: f >= at ? p : 0,
              filter: f >= at && p < 0.97 ? `blur(${(1 - p) * 10}px)` : undefined,
              transform: `translateY(${(1 - p) * 8}px)`,
            }}
          >
            {c}
          </span>
        );
      })}
    </span>
  );
};

// ---------- 1. Lockup (0–37) ----------
export const S1Lockup: React.FC<P> = ({f}) => {
  const zoom = f < 20 ? 1 : 1 - 0.0085 * (f - 20);
  const cl = arrive(f, 11, 0.3);
  const col = interpolateColors(f, [24, 30], [C.accent, C.ink]);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 26, transform: `scale(${zoom})`}}>
        <OpenAIMark size={150} />
        <TypeLetters f={f} text="GPT-6 Astra" start={1} per={1} size={128} color={C.ink} />
        <div style={{width: 60}} />
        <div style={{transform: `scale(${0.4 + 0.6 * cl})`, opacity: cl}}>
          <ClaudeMark size={150} color={f >= 24 ? col : C.accent} />
        </div>
        <TypeLetters f={f} text="Fable 5.1" start={17} per={1} size={128} color={col} />
      </div>
    </AbsoluteFill>
  );
};

// ---------- 2. Prompt box, push-in, click, type (38–101) ----------
export const S2Prompt: React.FC<P> = ({f}) => {
  const push = approach(f, 46, 0, 1, 0.2);
  const drift = (f - 38) * 0.0025;
  const s = (1.35 + 0.95 * push) * (1 + drift) * approach(f, 38, 1.12, 1, 0.25);
  // world focus: centre of the box at rest, box's left third when pushed
  const fx = 960 + (700 - 960) * push;
  const fy = 540 + (560 - 540) * push;
  const sx = 960 + (620 - 960) * push;
  const sy = 540 + (500 - 540) * push;
  const tx = sx - fx * s;
  const ty = sy - fy * s;
  // cursor (screen space)
  const cx = approach(f, 55, 1700, 980, 0.22);
  const cy = approach(f, 55, 1000, 560, 0.22);
  const press = f >= 66 && f < 70 ? 1 : 0;
  const ripple = clamp01((f - 67) / 10);
  const typed = 'Compare os dois';
  const n = Math.max(0, Math.min(typed.length, Math.floor((f - 72) / 1.3)));
  const caretOn = Math.floor(f / 6) % 2 === 0 || (f >= 72 && f < 94);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', inset: 0, transform: `translate(${tx}px, ${ty}px) scale(${s})`, transformOrigin: '0px 0px'}}>
        <div style={{position: 'absolute', top: 380, width: '100%', textAlign: 'center', fontSize: 50, fontWeight: 500, letterSpacing: '-0.02em'}}>
          Como posso ajudar?
        </div>
        <div
          style={{
            position: 'absolute',
            left: 420,
            top: 480,
            width: 1080,
            height: 150,
            borderRadius: 36,
            border: `2px solid ${C.line}`,
            boxShadow: '0 6px 24px rgba(0,0,0,0.05)',
            background: C.white,
          }}
        >
          <div style={{position: 'absolute', left: 34, top: 28, fontSize: 30, color: n > 0 ? C.ink : '#AEAEB2', fontWeight: 500}}>
            {n > 0 ? typed.slice(0, n) : 'Pergunte qualquer coisa'}
            {f >= 67 && caretOn && <span style={{display: 'inline-block', width: 3, height: 32, background: C.ink, marginLeft: 3, verticalAlign: -5}} />}
          </div>
          <div style={{position: 'absolute', left: 34, bottom: 22, fontSize: 32, color: C.gray, display: 'flex', gap: 26}}>
            <span>+</span>
            <span style={{fontSize: 26}}>⚙</span>
          </div>
          <div style={{position: 'absolute', right: 22, bottom: 20, width: 48, height: 48, borderRadius: 24, background: C.ink}} />
        </div>
      </div>
      {f >= 55 && (
        <>
          {f >= 67 && (
            <div
              style={{
                position: 'absolute',
                left: 990 - 40 * (1 + ripple * 1.5),
                top: 570 - 40 * (1 + ripple * 1.5),
                width: 80 * (1 + ripple * 1.5),
                height: 80 * (1 + ripple * 1.5),
                borderRadius: '50%',
                border: `3px solid ${C.accent}`,
                opacity: 0.5 * (1 - ripple),
              }}
            />
          )}
          <Cursor x={cx} y={cy} press={press} opacity={f > 92 ? clamp01(1 - (f - 92) / 4) : 1} />
        </>
      )}
    </AbsoluteFill>
  );
};

// ---------- 3. Icon + wordmark, delete, shrink (102–140) ----------
export const S3Icon: React.FC<P> = ({f}) => {
  const pop = approach(f, 102, 0.4, 1, 0.3);
  const shrink = f < 133 ? 1 : approach(f, 133, 1, 0.62, 0.3);
  const shift = f < 128 ? -360 : approach(f, 128, -360, 0, 0.22);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 44, transform: `translateX(${shift}px) scale(${1 + 0.003 * (f - 102)})`}}>
        <div
          style={{
            width: 330,
            height: 330,
            borderRadius: 84,
            background: C.white,
            boxShadow: '0 2px 6px rgba(0,0,0,0.05), 0 20px 50px rgba(0,0,0,0.08)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transform: `scale(${pop * shrink})`,
          }}
        >
          <ClaudeMark size={200} />
        </div>
        <div style={{width: 700, marginLeft: -10}}>
          <TypeLetters f={f} text="Fable 5.1" start={108} per={1.2} size={170} color={interpolateColors(f, [114, 122], [C.accent, C.ink])} delStart={128} delDur={10} />
        </div>
      </div>
    </AbsoluteFill>
  );
};

// ---------- 4. Tile morph + dotted iris (140–176) ----------
const IrisDots: React.FC<{r: number; alpha: number}> = ({r, alpha}) => {
  const dots: React.ReactNode[] = [];
  const ring = r * 0.35;
  const step = 16;
  for (let y = -r; y <= r; y += step) {
    for (let x = -r; x <= r; x += step) {
      const d = Math.hypot(x, y);
      if (d > r || d < r - ring) continue;
      const k = (x * 31 + y * 17) | 0;
      const a = alpha * (0.25 + 0.75 * hash(k, 3)) * (1 - Math.abs(d - (r - ring / 2)) / (ring / 2)) ;
      if (a < 0.05) continue;
      dots.push(<rect key={k + ':' + x} x={x + r - 4} y={y + r - 4} width={8} height={8} fill={C.accent} opacity={a} />);
    }
  }
  return (
    <svg width={r * 2} height={r * 2} style={{position: 'absolute', left: W / 2 - r, top: H / 2 - r}}>
      {dots}
    </svg>
  );
};

export const S4Tile: React.FC<P> = ({f}) => {
  const morph = arrive(f, 140, 0.3);
  const breathe = 1 + 0.02 * Math.sin((f - 140) / 5);
  const irisR = f < 160 ? 0 : approach(f, 160, 240, 1500, 0.16);
  const reveal = f >= 164;
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <div
        style={{
          width: 300,
          height: 300,
          borderRadius: 76,
          background: interpolateColors(morph, [0, 1], [C.white, C.ink]),
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transform: `scale(${(0.9 + 0.1 * morph) * breathe})`,
          boxShadow: '0 20px 50px rgba(0,0,0,0.10)',
          opacity: reveal ? clamp01(1 - (f - 164) / 4) : 1,
        }}
      >
        <div style={{position: 'absolute', opacity: 1 - morph}}>
          <ClaudeMark size={176} />
        </div>
        <div style={{opacity: morph, transform: `rotate(${(1 - morph) * -60}deg)`}}>
          <OpenAIMark size={176} color={C.white} />
        </div>
      </div>
      {f >= 160 && <IrisDots r={irisR} alpha={clamp01(1.4 - (f - 160) / 14)} />}
      {reveal && (
        <div style={{position: 'absolute', inset: 0, clipPath: `circle(${Math.max(0, irisR - irisR * 0.35)}px at 50% 50%)`}}>
          <ChatWindow f={f} scale={0.8 + 0.05 * clamp01((f - 164) / 12)} />
        </div>
      )}
    </AbsoluteFill>
  );
};

// ---------- 5. Desktop chat window, push into input corner (172–208) ----------
const ChatWindow: React.FC<{f: number; scale: number}> = ({f, scale}) => {
  const items = ['Novo chat', 'Benchmarks set/26', 'Roteiro VSL', 'Edição v5', 'Legendas karaokê', 'Trilha 96 BPM'];
  return (
    <div
      style={{
        position: 'absolute',
        left: W / 2 - 800,
        top: H / 2 - 450,
        width: 1600,
        height: 900,
        borderRadius: 28,
        border: `2px solid ${C.line}`,
        background: C.white,
        transform: `scale(${scale})`,
        transformOrigin: '50% 50%',
        overflow: 'hidden',
      }}
    >
      <div style={{position: 'absolute', left: 24, top: 22, display: 'flex', gap: 10}}>
        {['#FF5F57', '#FEBC2E', '#28C840'].map((c) => (
          <div key={c} style={{width: 16, height: 16, borderRadius: 8, background: c}} />
        ))}
      </div>
      <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: 300, borderRight: `2px solid ${C.soft}`, background: '#FAFAFA'}}>
        {items.map((t, i) => {
          const p = arrive(f, 176 + i * 3, 0.3);
          return (
            <div key={t} style={{position: 'absolute', left: 28, top: 90 + i * 52, fontSize: 24, color: i === 0 ? C.ink : C.gray, fontWeight: 500, opacity: f >= 176 + i * 3 ? p : 0, transform: `translateX(${(1 - p) * -20}px)`}}>
              {t}
            </div>
          );
        })}
      </div>
      <div style={{position: 'absolute', left: 300, right: 0, top: 330, textAlign: 'center', fontSize: 44, fontWeight: 500, letterSpacing: '-0.02em'}}>Como posso ajudar?</div>
      <div style={{position: 'absolute', left: 520, top: 420, width: 860, height: 130, borderRadius: 32, border: `2px solid ${C.line}`}}>
        <div style={{position: 'absolute', left: 28, top: 24, fontSize: 26, color: '#AEAEB2'}}>Pergunte qualquer coisa</div>
        <div style={{position: 'absolute', left: 28, bottom: 16, fontSize: 30, color: C.gray}}>+</div>
        <div style={{position: 'absolute', right: 18, bottom: 16, width: 44, height: 44, borderRadius: 22, background: C.ink}} />
      </div>
    </div>
  );
};

export const S5Window: React.FC<P> = ({f}) => {
  const settle = approach(f, 172, 0.85, 0.9, 0.2);
  const slow = 1 + 0.0025 * (f - 172);
  const dive = f < 194 ? 0 : approach(f, 194, 0, 1, 0.25);
  const s = settle * slow * (1 + dive * 7);
  // dive towards the input's bottom-left corner (window coords -> screen)
  const ox = 520 + (W / 2 - 800);
  const oy = 550 + (H / 2 - 450);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', inset: 0, transform: `scale(${s})`, transformOrigin: `${ox}px ${oy}px`}}>
        <ChatWindow f={f} scale={1} />
      </div>
    </AbsoluteFill>
  );
};

// ---------- 6. Close-up typing inside the box (208–452) ----------
const PHRASES: {start: number; end: number; words: Word[]}[] = [
  {
    start: 244,
    end: 318,
    words: [
      {t: 'Compare', at: 248},
      {t: 'o', at: 254, color: C.gray},
      {t: 'Fable 5.1', at: 258, color: C.accent},
      {t: 'com', at: 266, color: C.gray},
      {t: 'o', at: 270, color: C.gray},
      {t: 'GPT-6 Astra', at: 274, color: C.accent},
    ],
  },
  {
    start: 312,
    end: 366,
    words: [
      {t: 'em', at: 316, color: C.gray},
      {t: 'código', at: 319, color: C.accent},
      {t: 'e', at: 324, color: C.gray},
      {t: 'matemática,', at: 327, color: C.accent},
    ],
  },
  {
    start: 360,
    end: 404,
    words: [
      {t: 'raciocínio', at: 364, color: C.accent},
      {t: 'e', at: 370, color: C.gray},
      {t: 'trabalho real', at: 373, color: C.accent},
    ],
  },
  {
    start: 398,
    end: 470,
    words: [
      {t: 'e me diga', at: 402, color: C.gray},
      {t: 'quem', at: 412, color: C.ink},
      {t: 'vence.', at: 417, color: C.accent},
    ],
  },
];

export const S6Typing: React.FC<P> = ({f}) => {
  // "@Placar" in the corner of the giant box, then the camera tracks the words
  const tag = f < 244 ? 0 : approach(f, 244, 0, 1, 0.22);
  const cornerOut = f < 244 ? 0 : easeIn(f, 244, 10, 0, 1);
  const settle = approach(f, 208, 1.25, 1, 0.25);
  const pan = -(f - 208) * 3;
  return (
    <AbsoluteFill style={{transform: f < 244 ? `translateX(${pan}px) scale(${settle})` : undefined}}>
      {/* giant rounded corner of the input box */}
      <div
        style={{
          position: 'absolute',
          left: 180 - 1400 * cornerOut,
          top: 200,
          width: 3000,
          height: 1400,
          borderRadius: 260,
          border: `4px solid ${C.ink}`,
          borderRightColor: 'transparent',
          borderBottomColor: 'transparent',
          opacity: 0.85 * (1 - cornerOut),
        }}
      />
      {f < 244 && <div style={{position: 'absolute', left: 300, top: 860, fontSize: 90, fontWeight: 300, color: C.ink}}>+</div>}
      <div style={{position: 'absolute', left: 420 - 1400 * tag, top: 400 + 40 * tag, transform: `scale(${1 - 0.25 * tag})`, transformOrigin: 'left center'}}>
        <TypeLetters f={f} text="@Placar" start={216} per={3} size={170} color={C.ink} weight={700} />
      </div>
      {PHRASES.map((ph, i) => {
        if (f < ph.start || f >= ph.end) return null;
        const last = ph.words[ph.words.length - 1];
        const typedUntil = last.at + 8;
        // camera: keeps the caret on screen, then drifts left (nothing freezes)
        // caret x (estimated from typed characters) must stay left of 1450px
        const x0 = i === 0 ? 700 : 170;
        // smooth camera: each new word moves the camera with the same arrive-fast/land-soft curve
        let track = 0;
        let chars = 0;
        let prevNeed = 0;
        for (const w of ph.words) {
          chars += w.t.length + 1;
          const need = Math.max(0, x0 + chars * 150 * 0.47 - 1650);
          if (f >= w.at) track = -(prevNeed + (need - prevNeed) * arrive(f, w.at, 0.22));
          prevNeed = need;
        }
        const drift = -(f - ph.start) * 2;
        const isLast = i === PHRASES.length - 1;
        const out = isLast ? 0 : easeIn(f, ph.end - 6, 6, 0, 1);
        const inY = approach(f, ph.start, 160, 0, 0.3);
        const sendPush = isLast && f >= 452 ? approach(f, 452, 0, 1, 0.25) : 0;
        return (
          <DirBlur
            key={i}
            y={out * 40 + (1 - arrive(f, ph.start, 0.3)) * 18}
            x={sendPush * 30 * (1 - arrive(f, 460, 0.3))}
            style={{
              position: 'absolute',
              left: x0 + track + drift - sendPush * 1400,
              top: 430 + inY - out * 500,
              opacity: 1 - out,
            }}
          >
            <TypedWords f={f} words={ph.words} size={150} />
          </DirBlur>
        );
      })}
    </AbsoluteFill>
  );
};

// ---------- 7+8. Send button, push, click, pixel burst (452–490) ----------
export const S7Send: React.FC<P> = ({f}) => {
  const pop = approach(f, 452, 0, 1, 0.3);
  const push = approach(f, 456, 0, 1, 0.25);
  const bx = interpolate(push, [0, 1], [1560, W / 2]);
  const by = interpolate(push, [0, 1], [520, H / 2]);
  const size = 110 * (1 + push * 3.9);
  const press = f >= 469 && f < 473 ? 0.9 : 1;
  const fly = f < 472 ? 0 : easeIn(f, 472, 14, 0, 1);
  const cx = approach(f, 458, 1700, W / 2 + 20, 0.22);
  const cy = approach(f, 458, 1000, H / 2 + 10, 0.22);
  const burst = f >= 471 ? f - 471 : -1;
  return (
    <AbsoluteFill>
      {burst >= 0 &&
        Array.from({length: 90}).map((_, i) => {
          const a = hash(i, 1) * Math.PI * 2;
          const dist = 200 + hash(i, 2) * 700;
          const p = approach(burst, 0, 0, 1, 0.18);
          const s = 18 + hash(i, 4) * 46;
          const col = hash(i, 5) < 0.6 ? C.accent : hash(i, 6) < 0.5 ? '#F2C4B3' : C.ink;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: W / 2 + Math.cos(a) * dist * p - s / 2,
                top: H / 2 + Math.sin(a) * dist * p - s / 2,
                width: s,
                height: s,
                background: col,
                opacity: clamp01(1 - burst / 19) * (0.5 + 0.5 * hash(i, 7)),
              }}
            />
          );
        })}
      <DirBlur y={fly * 30}>
        <div
          style={{
            position: 'absolute',
            left: bx - size / 2,
            top: by - size / 2 - fly * 2000,
            width: size,
            height: size,
            borderRadius: '50%',
            background: C.ink,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transform: `scale(${pop * press * (1 + fly * 1.5)})`,
          }}
        >
          <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24">
            <path d="M4 12 H19 M13 6 L19 12 L13 18" stroke={C.white} strokeWidth={2.6} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </DirBlur>
      {f >= 458 && f < 478 && <Cursor x={cx} y={cy} press={f >= 469 && f < 473 ? 1 : 0} opacity={clamp01(1 - (f - 474) / 4)} />}
    </AbsoluteFill>
  );
};

// ---------- 9+10. Message bubble, "Analisando…", whip-zoom (490–530) ----------
export const S9Bubble: React.FC<P> = ({f}) => {
  const inY = approach(f, 486, 420, 0, 0.35);
  const push = f < 500 ? 1 : approach(f, 500, 1, 1.45, 0.15);
  const whip = f < 516 ? 0 : easeIn(f, 516, 12, 0, 1);
  const shimmer = ((f - 486) * 40) % 900;
  return (
    <AbsoluteFill>
      <DirBlur y={(1 - arrive(f, 486, 0.35)) * 26} x={whip * 60} style={{position: 'absolute', inset: 0}}>
        <div style={{position: 'absolute', inset: 0, transform: `scale(${push * (1 + whip * 9)})`, transformOrigin: '330px 625px'}}>
          <div
            style={{
              position: 'absolute',
              left: 170,
              top: 330 + inY,
              width: 1900,
              padding: '38px 44px',
              borderRadius: 40,
              background: C.soft,
              opacity: 1 - clamp01(whip * 4),
              fontSize: 44,
              lineHeight: 1.35,
              letterSpacing: '-0.02em',
              color: C.ink,
            }}
          >
            <span style={{fontWeight: 700}}>@Placar</span> Compare o <span style={{color: C.accent}}>Fable 5.1</span> com o{' '}
            <span style={{color: C.accent}}>GPT-6 Astra</span> em código e matemática,
            <br />
            raciocínio e trabalho real e me diga quem vence.
          </div>
          <div
            style={{
              position: 'absolute',
              left: 214,
              top: 600 + inY,
              fontSize: 48,
              fontWeight: 600,
              color: whip > 0.05 ? C.accent : C.gray,
              backgroundImage: whip > 0.05 ? undefined : `linear-gradient(90deg, ${C.gray} 0px, ${C.gray} ${shimmer}px, ${C.ink} ${shimmer + 40}px, ${C.gray} ${shimmer + 90}px)`,
              WebkitBackgroundClip: whip > 0.05 ? undefined : 'text',
              WebkitTextFillColor: whip > 0.05 ? undefined : 'transparent',
            }}
          >
            Analisando…
          </div>
        </div>
      </DirBlur>
    </AbsoluteFill>
  );
};

// ---------- 11+12. Scattered benchmark tiles, zoom to the tie (528–590) ----------
const TILES = [
  {x: 140, y: 110, w: 330, logo: 'gpt', score: '57,9', name: 'Terminal-Bench 4.0'},
  {x: 560, y: 40, w: 300, logo: 'claude', score: '55,8', name: 'Terminal-Bench 4.0'},
  {x: 1300, y: 90, w: 360, logo: 'gpt', score: '97,6', name: 'FrontierMath T4'},
  {x: 1440, y: 520, w: 330, logo: 'claude', score: '87,8', name: 'FrontierMath T4'},
  {x: 80, y: 600, w: 340, logo: 'claude', score: '65,0', name: "Humanity's Last Exam"},
  {x: 470, y: 760, w: 300, logo: 'gpt', score: '57,2', name: "Humanity's Last Exam"},
  {x: 1180, y: 740, w: 320, logo: 'gpt', score: '41,4', name: 'AutomationBench'},
  {x: 820, y: 380, w: 280, logo: 'claude', score: '31,4', name: 'AutomationBench'},
];

const Tile: React.FC<{t: (typeof TILES)[number]; f: number; i: number}> = ({t, f, i}) => {
  const at = 526 + i;
  const p = arrive(f, at, 0.35);
  const done = f >= 548 + i * 3;
  return (
    <div
      style={{
        position: 'absolute',
        left: t.x,
        top: t.y,
        width: t.w * 1.25,
        padding: 30,
        borderRadius: 34,
        background: C.white,
        border: `2px solid ${C.soft}`,
        boxShadow: '0 12px 36px rgba(0,0,0,0.08)',
        transform: `scale(${0.6 + 0.4 * p})`,
        opacity: f >= at ? p : 0,
      }}
    >
      {t.logo === 'gpt' ? <OpenAIMark size={44} /> : <ClaudeMark size={44} />}
      <div style={{fontSize: 76, fontWeight: 700, letterSpacing: '-0.04em', marginTop: 10}}>
        {t.score}
        <span style={{fontSize: 36}}>%</span>
      </div>
      <div style={{fontSize: 22, fontWeight: 600, color: C.ink}}>{t.name}</div>
      <div style={{fontSize: 20, fontWeight: 600, color: done ? C.gray : C.accent, marginTop: 6}}>{done ? 'Concluído' : 'Analisando…'}</div>
    </div>
  );
};

// From 572 the dark tile flies to where the result card's tile sits at 590, so S13 only builds rows.
export const CARD_TILE = {x: -586, y: -51, s: (330 * 1.45) / 480};
const base = (g: number) => (0.5 + 1.1 * arrive(g, 562, 0.2)) * (1 + 0.004 * (g - 562));
export const TILE_K = 0.18;
export const tileRest = (f: number) => (f < 568 ? 1 : Math.pow(1 - TILE_K, f - 568)); // remaining distance
const toCard = (f: number) => {
  if (f < 568) return {x: 0, y: 0, s: base(f)};
  const r = tileRest(f);
  return {x: CARD_TILE.x * (1 - r), y: CARD_TILE.y * (1 - r), s: CARD_TILE.s + (base(568) - CARD_TILE.s) * r};
};
export const tileZoomAt = (f: number) => toCard(f).s / CARD_TILE.s;

export const S11Grid: React.FC<P> = ({f}) => {
  const zoomOut = approach(f, 528, 1.5, 1, 0.2);
  const toCenter = f < 562 ? 0 : approach(f, 562, 0, 1, 0.18);
  const spread = f < 556 ? 0 : easeIn(f, 556, 14, 0, 1);
  const centerIn = f < 562 ? 0 : arrive(f, 562, 0.2);
  return (
    <AbsoluteFill>
      <DirBlur x={(zoomOut - 1) * 6} style={{position: 'absolute', inset: 0}}>
        <div style={{position: 'absolute', inset: 0, transform: `scale(${zoomOut * (1 + 0.5 * toCenter) * (1 + 0.003 * (f - 528))})`, transformOrigin: '50% 50%'}}>
          {TILES.map((t, i) => {
            const vx = t.x + t.w * 0.62 - W / 2;
            const vy = t.y + 170 - H / 2;
            const len = Math.hypot(vx, vy) || 1;
            const dx = (vx / len) * 1500 * spread;
            const dy = (vy / len) * 1500 * spread;
            return (
              <div key={i} style={{position: 'absolute', inset: 0, transform: `translate(${dx}px, ${dy}px)`}}>
                <Tile t={t} f={f} i={i} />
              </div>
            );
          })}
        </div>
      </DirBlur>
      {f >= 562 && (
        <div
          style={{
            position: 'absolute',
            left: W / 2 - 240,
            top: H / 2 - 240,
            width: 480,
            height: 480,
            borderRadius: 104,
            background: C.ink,
            color: C.white,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 14,
            transform: `translate(${toCard(f).x}px, ${toCard(f).y}px) scale(${toCard(f).s})`,
            opacity: centerIn,
          }}
        >
          <div style={{fontSize: 168, fontWeight: 800, letterSpacing: '-0.05em', lineHeight: 1}}>53</div>
          <div style={{fontSize: 44, fontWeight: 700, color: C.accent}}>= 53</div>
        </div>
      )}
    </AbsoluteFill>
  );
};

// ---------- 13. Result card builds line by line, exits left (590–622) ----------
const ROWS = [
  {k: 'Índice de Inteligência', a: '53', b: '53'},
  {k: 'Terminal-Bench 4.0', a: '55,8', b: '57,9'},
  {k: 'FrontierMath T4', a: '87,8', b: '97,6'},
  {k: "Humanity's Last Exam", a: '65,0', b: '57,2'},
  {k: 'AutomationBench', a: '31,4', b: '41,4'},
];

export const ResultCard: React.FC<{f: number; start: number; big?: boolean}> = ({f, start, big}) => (
  <div style={{display: 'flex', alignItems: 'flex-start', gap: 48}}>
    <div
      style={{
        width: 330,
        height: 330,
        borderRadius: 72,
        background: C.ink,
        color: C.white,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
      }}
    >
      <div style={{fontSize: 116, fontWeight: 800, letterSpacing: '-0.05em', lineHeight: 1}}>53</div>
      <div style={{fontSize: 30, fontWeight: 700, color: C.accent}}>= 53</div>
    </div>
    <div style={{width: 760}}>
      {[
        <div key="h" style={{display: 'flex', alignItems: 'center', gap: 12, fontSize: 24, fontWeight: 700, color: C.accent}}>
          <ClaudeMark size={28} /> Fable 5.1 <span style={{color: C.gray}}>×</span> <OpenAIMark size={28} /> <span style={{color: C.ink}}>GPT-6 Astra</span>
        </div>,
        <div key="t" style={{fontSize: 56, fontWeight: 700, letterSpacing: '-0.035em', marginTop: 8}}>Empate técnico</div>,
        ...ROWS.map((r) => (
          <div key={r.k} style={{display: 'flex', justifyContent: 'space-between', fontSize: 28, marginTop: 14, borderBottom: `2px solid ${C.soft}`, paddingBottom: 10}}>
            <span style={{color: C.gray, fontWeight: 500}}>{r.k}</span>
            <span style={{fontWeight: 700, fontVariantNumeric: 'tabular-nums'}}>
              <span style={{color: C.accent}}>{r.a}</span> <span style={{color: '#C7C7CC'}}>×</span> {r.b}
            </span>
          </div>
        )),
      ].map((el, i) => {
        const at = start + 2 + i * 2;
        const p = big ? 1 : arrive(f, at, 0.3);
        return (
          <div key={i} style={{opacity: big || f >= at ? p : 0, transform: `translateY(${(1 - p) * 24}px)`, filter: !big && f >= at && p < 0.95 ? `blur(${(1 - p) * 8}px)` : undefined}}>
            {el}
          </div>
        );
      })}
    </div>
  </div>
);

export const S13Card: React.FC<P> = ({f}) => {
  const out = f < 609 ? 0 : easeIn(f, 609, 10, 0, 1);
  const push = 1 + 0.0025 * Math.max(0, f - 590);
  // continue the tile's flight from S11: tile centre follows the same curve, the card scales around it
  const z = tileZoomAt(f);
  const r = tileRest(f);
  const tx = push * CARD_TILE.x * (1 - r - z);
  const ty = push * CARD_TILE.y * (1 - r - z);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <DirBlur x={out * 50}>
        <div style={{transform: `translate(${tx - out * 1900}px, ${ty}px) scale(${1.45 * push * z})`}}>
          <ResultCard f={f} start={584} />
        </div>
      </DirBlur>
    </AbsoluteFill>
  );
};

// ---------- 14. Tagline word by word, drift, whip left (622–686) ----------
const TAG: Word[] = [
  {t: 'O', at: 618},
  {t: 'melhor', at: 620},
  {t: 'modelo', at: 623},
  {t: 'depende', at: 626},
  {t: 'da', at: 629},
  {t: 'sua', at: 631},
  {t: 'tarefa.', at: 633},
];

export const S14Tagline: React.FC<P> = ({f}) => {
  const drift = 90 - (f - 618) * 3;
  const whip = f < 676 ? 0 : easeIn(f, 676, 10, 0, 1);
  const words = TAG.map((w) => ({...w, color: interpolateColors(f, [w.at + 6, w.at + 14], [C.accent, C.ink])}));
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
      <DirBlur x={whip * 80}>
        <div style={{transform: `translateX(${drift - whip * 2600}px)`}}>
          <TypedWords f={f} words={words} size={80} gap={0.26} />
        </div>
      </DirBlur>
    </AbsoluteFill>
  );
};

// ---------- 15. Final card returns big, cursor, sources (686–720) ----------
export const S15End: React.FC<P> = ({f}) => {
  const s = approach(f, 686, 1.55, 1.3, 0.12);
  const cx = approach(f, 692, 1750, 700, 0.2);
  const cy = approach(f, 692, 1050, 560, 0.2);
  const pressed = f >= 707 && f < 711;
  const pulse = f < 707 ? 1 : 1 + 0.03 * Math.exp(-(f - 707) / 4) * Math.sin((f - 707) / 1.5);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{transform: `scale(${s * pulse})`}}>
        <ResultCard f={f} start={0} big />
      </div>
      <div style={{position: 'absolute', bottom: 46, left: 0, right: 0, textAlign: 'center', fontSize: 30, color: '#8E8E93', fontWeight: 500}}>
        Fontes: OpenAI (tabela do GPT-6 Astra), Artificial Analysis e Vellum, set. 2026
      </div>
      {f >= 692 && <Cursor x={cx} y={cy} press={pressed ? 1 : 0} />}
    </AbsoluteFill>
  );
};
