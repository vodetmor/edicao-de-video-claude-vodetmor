import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {C, FONT, fontCss} from './kit';
import {S11Grid, S13Card, S14Tagline, S15End, S1Lockup, S2Prompt, S3Icon, S4Tile, S5Window, S6Typing, S7Send, S9Bubble} from './Shots';

// Shot ranges (24 fps), copied from SPEC.md
const SHOTS: [number, number, React.FC<{f: number}>][] = [
  [0, 38, S1Lockup],
  [38, 102, S2Prompt],
  [102, 140, S3Icon],
  [140, 176, S4Tile],
  [172, 208, S5Window],
  [208, 472, S6Typing],
  [452, 490, S7Send],
  [486, 530, S9Bubble],
  [528, 586, S11Grid],
  [586, 619, S13Card],
  [618, 686, S14Tagline],
  [686, 720, S15End],
];
export const V6_FRAMES = 720;

export const V6: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: C.bg, color: C.ink, fontFamily: `${FONT}, sans-serif`, overflow: 'hidden'}}>
      <style>{fontCss}</style>
      {withAudio && <Audio src={staticFile('v6-mix.wav')} />}
      {SHOTS.filter(([a, b]) => f >= a && f < b).map(([a, , Shot]) => (
        <AbsoluteFill key={a}>
          <Shot f={f} />
        </AbsoluteFill>
      ))}
    </AbsoluteFill>
  );
};
