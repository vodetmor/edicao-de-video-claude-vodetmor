import React from 'react';
import {Composition} from 'remotion';
import {Benchmark, TOTAL} from './Benchmark';
import {V6, V6_FRAMES} from './v6/V6';

export const Root: React.FC = () => (
  <>
    <Composition id="Benchmark" component={Benchmark} durationInFrames={TOTAL} fps={30} width={1080} height={1920} />
    <Composition id="V6" component={V6} durationInFrames={V6_FRAMES} fps={24} width={1920} height={1080} defaultProps={{withAudio: true}} />
  </>
);
