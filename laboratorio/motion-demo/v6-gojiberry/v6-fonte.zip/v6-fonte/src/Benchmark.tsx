import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';

// Timeline (30 fps). Every scene is a multiple of 75 frames = 4 beats at 96 BPM,
// so cuts land on the downbeat of the soundtrack (see audio/make_audio.py).
export const S = {
  intro: [0, 75],
  logos: [75, 150],
  bench: [225, 300], // 4 cards x 75
  tie: [525, 75],
  price: [600, 150],
  outro: [750, 150],
} as const;
export const TOTAL = 900;

const C = {
  bg: '#F5F5F7',
  card: '#FFFFFF',
  ink: '#1D1D1F',
  sub: '#6E6E73',
  faint: '#AEAEB2',
  track: '#E8E8ED',
  claude: '#D97757',
  gpt: '#1D1D1F',
  black: '#000000',
  white: '#FFFFFF',
};

const FONT = 'InterLocal';
const fontCss = [400, 500, 600, 700, 800]
  .map(
    (w) =>
      `@font-face{font-family:${FONT};font-weight:${w};src:url(${staticFile(
        `inter-latin-${w}-normal.woff2`,
      )}) format('woff2');}`,
  )
  .join('');

const BENCH = [
  {cat: 'Código', name: 'Terminal-Bench 4.0', desc: 'Agentes resolvendo tarefas reais no terminal', claude: 55.8, gpt: 57.9},
  {cat: 'Matemática', name: 'FrontierMath T4', desc: 'Problemas de matemática de nível pesquisa', claude: 87.8, gpt: 97.6},
  {cat: 'Raciocínio', name: "Humanity's Last Exam", desc: 'Perguntas de especialistas, com ferramentas', claude: 65.0, gpt: 57.2},
  {cat: 'Trabalho', name: 'AutomationBench', desc: 'Automação de fluxos de trabalho profissionais', claude: 31.4, gpt: 41.4},
];

// ---------- helpers ----------
const useSpring = (delay = 0, damping = 18, mass = 0.8) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: {damping, mass, stiffness: 140}});
};

const exitOut = (frame: number, dur: number, len = 10) =>
  interpolate(frame, [dur - len, dur], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });

const Rise: React.FC<{delay?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({
  delay = 0,
  children,
  style,
}) => {
  const s = useSpring(delay);
  return (
    <div style={{opacity: s, transform: `translateY(${(1 - s) * 50}px)`, ...style}}>{children}</div>
  );
};

const fmt = (v: number, d = 1) => v.toFixed(d).replace('.', ',');

// ---------- marks (simplified, drawn from scratch) ----------
export const ClaudeMark: React.FC<{size: number; t?: number; color?: string}> = ({size, t = 1, color = C.claude}) => {
  const lens = [1, 0.7, 0.92, 0.64, 0.98, 0.74, 0.88, 0.62, 1, 0.7, 0.9, 0.66];
  return (
    <svg width={size} height={size} viewBox="-100 -100 200 200">
      {lens.map((l, i) => {
        const p = interpolate(t, [i * 0.04, i * 0.04 + 0.52], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
          easing: Easing.out(Easing.cubic),
        });
        const a = ((i * 30 + (i % 2) * 6 - 90) * Math.PI) / 180;
        const r0 = 10;
        const r1 = r0 + (l * 80 - r0) * p;
        return (
          <line
            key={i}
            x1={Math.cos(a) * r0}
            y1={Math.sin(a) * r0}
            x2={Math.cos(a) * r1}
            y2={Math.sin(a) * r1}
            stroke={color}
            strokeWidth={17}
            strokeLinecap="round"
            opacity={p > 0 ? 1 : 0}
          />
        );
      })}
    </svg>
  );
};

export const GptMark: React.FC<{size: number; t?: number; color?: string}> = ({size, t = 1, color = C.gpt}) => {
  const rot = interpolate(t, [0, 1], [-120, 0], {easing: Easing.out(Easing.cubic)});
  return (
    <svg width={size} height={size} viewBox="-100 -100 200 200">
      <g transform={`rotate(${rot})`}>
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const p = interpolate(t, [i * 0.06, i * 0.06 + 0.5], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          });
          return (
            <g key={i} transform={`rotate(${i * 60})`} opacity={p}>
              <rect
                x={-9}
                y={-78}
                width={46}
                height={96}
                rx={23}
                fill="none"
                stroke={color}
                strokeWidth={13}
                transform={`scale(${0.6 + 0.4 * p})`}
              />
            </g>
          );
        })}
      </g>
    </svg>
  );
};

// ---------- scenes ----------
const Intro: React.FC = () => {
  const frame = useCurrentFrame();
  const out = exitOut(frame, S.intro[1]);
  return (
    <AbsoluteFill style={{justifyContent: 'center', padding: '0 96px', opacity: 1 - out, transform: `translateY(${-80 * out}px) scale(${interpolate(frame, [0, S.intro[1]], [1, 1.04])})`}}>
      <Rise delay={0}>
        <div style={{fontSize: 118, fontWeight: 700, letterSpacing: '-0.04em', lineHeight: 1.02}}>Dois modelos novos.</div>
      </Rise>
      <Rise delay={16}>
        <div style={{fontSize: 118, fontWeight: 700, letterSpacing: '-0.04em', lineHeight: 1.02, color: C.sub, marginTop: 12}}>
          Um placar honesto.
        </div>
      </Rise>
    </AbsoluteFill>
  );
};

const Tile: React.FC<{delay: number; from: number; children: React.ReactNode; name: string; maker: string}> = ({
  delay,
  from,
  children,
  name,
  maker,
}) => {
  const s = useSpring(delay, 16, 0.9);
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', transform: `translateX(${(1 - s) * from}px)`, opacity: s}}>
      <div
        style={{
          width: 400,
          height: 400,
          borderRadius: 96,
          background: C.card,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 2px 6px rgba(0,0,0,0.04), 0 24px 48px rgba(0,0,0,0.06)',
        }}
      >
        {children}
      </div>
      <div style={{fontSize: 52, fontWeight: 700, letterSpacing: '-0.03em', marginTop: 44}}>{name}</div>
      <div style={{fontSize: 32, fontWeight: 500, color: C.sub, marginTop: 6}}>{maker}</div>
    </div>
  );
};

const Logos: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t1 = spring({frame: frame - 8, fps, config: {damping: 200}, durationInFrames: 40});
  const t2 = spring({frame: frame - 16, fps, config: {damping: 200}, durationInFrames: 40});
  const vs = useSpring(30, 12, 0.6);
  const out = exitOut(frame, S.logos[1], 12);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', opacity: 1 - out, transform: `scale(${(1 - 0.06 * out) * interpolate(frame, [0, S.logos[1]], [0.97, 1.03])})`}}>
      <Rise delay={42} style={{position: 'absolute', top: 360, width: '100%', textAlign: 'center'}}>
        <div style={{fontSize: 96, fontWeight: 700, letterSpacing: '-0.04em'}}>Frente a frente.</div>
      </Rise>
      <div style={{display: 'flex', gap: 60, alignItems: 'flex-start', marginTop: 120}}>
        <Tile delay={0} from={-400} name="Fable 5.1" maker="Anthropic · Claude">
          <ClaudeMark size={260} t={t1} />
        </Tile>
        <Tile delay={6} from={400} name="GPT-6 Astra" maker="OpenAI · ChatGPT">
          <GptMark size={250} t={t2} />
        </Tile>
      </div>
      <div
        style={{
          position: 'absolute',
          top: 960 + 60 - 60,
          left: 540 - 56,
          width: 112,
          height: 112,
          borderRadius: 56,
          background: C.ink,
          color: C.white,
          fontSize: 40,
          fontWeight: 700,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transform: `scale(${vs})`,
          marginTop: -200,
        }}
      >
        vs
      </div>
    </AbsoluteFill>
  );
};

// Winner moment inside each 75-frame card
const WIN_AT = 44;

const Row: React.FC<{label: string; color: string; value: number; win: boolean; delay: number; mark: React.ReactNode}> = ({
  label,
  color,
  value,
  win,
  delay,
  mark,
}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [delay, delay + 28], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const decided = interpolate(frame, [WIN_AT, WIN_AT + 8], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const {fps} = useVideoConfig();
  const pill = spring({frame: frame - WIN_AT, fps, config: {damping: 11, stiffness: 180}});
  const dim = win ? 1 : 1 - 0.55 * decided;
  return (
    <div style={{marginTop: 56}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 18, opacity: dim}}>
        {mark}
        <div style={{fontSize: 38, fontWeight: 600, letterSpacing: '-0.02em'}}>{label}</div>
        {win && (
          <div
            style={{
              marginLeft: 'auto',
              background: C.ink,
              color: C.white,
              fontSize: 28,
              fontWeight: 700,
              padding: '8px 22px',
              borderRadius: 40,
              transform: `scale(${pill})`,
              opacity: pill > 0.02 ? 1 : 0,
            }}
          >
            Vence
          </div>
        )}
      </div>
      <div style={{display: 'flex', alignItems: 'center', gap: 28, marginTop: 18}}>
        <div style={{flex: 1, height: 36, borderRadius: 18, background: C.track, overflow: 'hidden'}}>
          <div style={{width: `${value * p}%`, height: '100%', borderRadius: 18, background: color, opacity: dim}} />
        </div>
        <div
          style={{
            width: 250,
            textAlign: 'right',
            fontSize: 88,
            fontWeight: 700,
            letterSpacing: '-0.04em',
            fontVariantNumeric: 'tabular-nums',
            color: win ? C.ink : interpolate(decided, [0, 1], [0, 1]) > 0.5 ? C.faint : C.ink,
          }}
        >
          {fmt(value * p)}
          <span style={{fontSize: 44, fontWeight: 600}}>%</span>
        </div>
      </div>
    </div>
  );
};

const BenchCard: React.FC<{b: (typeof BENCH)[number]; i: number}> = ({b, i}) => {
  const frame = useCurrentFrame();
  const inS = useSpring(-4, 20, 0.8);
  const out = exitOut(frame, 75, 10);
  const claudeWins = b.claude > b.gpt;
  return (
    <AbsoluteFill style={{padding: '0 64px', justifyContent: 'center'}}>
      <div
        style={{
          background: C.card,
          borderRadius: 72,
          padding: '72px 64px 80px',
          boxShadow: '0 2px 6px rgba(0,0,0,0.04), 0 24px 48px rgba(0,0,0,0.06)',
          transform: `translateX(${(1 - inS) * 700 - out * 700}px) rotate(${(1 - inS) * 2}deg)`,
          opacity: Math.min(inS * 1.4, 1 - out),
          marginTop: 60,
        }}
      >
        <div style={{display: 'flex', justifyContent: 'space-between', fontSize: 30, fontWeight: 600, color: C.sub, textTransform: 'uppercase', letterSpacing: '0.08em'}}>
          <span>{b.cat}</span>
          <span style={{fontVariantNumeric: 'tabular-nums'}}>{i + 1} / 4</span>
        </div>
        <div style={{fontSize: 76, fontWeight: 700, letterSpacing: '-0.04em', marginTop: 18, lineHeight: 1.02}}>{b.name}</div>
        <div style={{fontSize: 34, fontWeight: 500, color: C.sub, marginTop: 14, lineHeight: 1.25}}>{b.desc}</div>
        <Row label="Fable 5.1" color={C.claude} value={b.claude} win={claudeWins} delay={10} mark={<ClaudeMark size={48} />} />
        <Row label="GPT-6 Astra" color={C.gpt} value={b.gpt} win={!claudeWins} delay={16} mark={<GptMark size={46} />} />
      </div>
    </AbsoluteFill>
  );
};

// Running score in the header during the benchmark cards
const Tally: React.FC = () => {
  const frame = useCurrentFrame(); // local to bench sequence
  let c = 0;
  let g = 0;
  BENCH.forEach((b, i) => {
    if (frame >= i * 75 + WIN_AT) {
      if (b.claude > b.gpt) c++;
      else g++;
    }
  });
  const inS = useSpring(0, 20);
  const out = exitOut(frame, S.bench[1], 10);
  const bump = (at: number[]) => {
    const last = at.filter((a) => frame >= a).pop();
    if (last === undefined) return 1;
    return 1 + 0.25 * Math.max(0, 1 - (frame - last) / 8);
  };
  const cAt = BENCH.map((b, i) => (b.claude > b.gpt ? i * 75 + WIN_AT : -1)).filter((x) => x >= 0);
  const gAt = BENCH.map((b, i) => (b.claude <= b.gpt ? i * 75 + WIN_AT : -1)).filter((x) => x >= 0);
  return (
    <div
      style={{
        position: 'absolute',
        top: 150,
        width: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 36,
        opacity: inS * (1 - out),
        transform: `translateY(${(1 - inS) * -40}px)`,
      }}
    >
      <ClaudeMark size={64} />
      <div style={{fontSize: 96, fontWeight: 800, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', display: 'flex', gap: 28}}>
        <span style={{display: 'inline-block', transform: `scale(${bump(cAt)})`}}>{c}</span>
        <span style={{color: C.faint}}>×</span>
        <span style={{display: 'inline-block', transform: `scale(${bump(gAt)})`}}>{g}</span>
      </div>
      <GptMark size={62} />
    </div>
  );
};

const Tie: React.FC = () => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [4, 30], [0, 53], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const {fps} = useVideoConfig();
  const hit = spring({frame: frame - 34, fps, config: {damping: 12, stiffness: 160}});
  const out = exitOut(frame, S.tie[1], 8);
  return (
    <AbsoluteFill style={{background: C.black, color: C.white, alignItems: 'center', justifyContent: 'center'}}>
      <div style={{opacity: 1 - out, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <Rise delay={0}>
          <div style={{fontSize: 34, fontWeight: 600, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.1em', textAlign: 'center'}}>
            Índice de Inteligência
          </div>
        </Rise>
        <div style={{display: 'flex', alignItems: 'center', gap: 70, marginTop: 50}}>
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20}}>
            <ClaudeMark size={90} />
            <div style={{fontSize: 220, fontWeight: 800, letterSpacing: '-0.05em', fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>{Math.round(p)}</div>
          </div>
          <div style={{fontSize: 90, fontWeight: 700, color: '#48484A'}}>=</div>
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20}}>
            <GptMark size={86} color={C.white} />
            <div style={{fontSize: 220, fontWeight: 800, letterSpacing: '-0.05em', fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>{Math.round(p)}</div>
          </div>
        </div>
        <div style={{fontSize: 150, fontWeight: 800, letterSpacing: '-0.05em', marginTop: 70, transform: `scale(${hit})`, opacity: hit > 0.02 ? 1 : 0}}>
          Empate.
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Price: React.FC = () => {
  const frame = useCurrentFrame();
  const out = exitOut(frame, S.price[1], 12);
  const card2 = useSpring(66, 20);
  const bar = (at: number, v: number) =>
    interpolate(frame, [at, at + 26], [0, v], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const cardStyle: React.CSSProperties = {
    background: C.card,
    borderRadius: 64,
    padding: '56px 60px',
    boxShadow: '0 2px 6px rgba(0,0,0,0.04), 0 24px 48px rgba(0,0,0,0.06)',
  };
  return (
    <AbsoluteFill style={{padding: '0 64px', justifyContent: 'center', opacity: 1 - out, transform: `translateY(${-60 * out}px)`}}>
      <Rise delay={0}>
        <div style={cardStyle}>
          <div style={{fontSize: 30, fontWeight: 600, color: C.sub, textTransform: 'uppercase', letterSpacing: '0.08em'}}>Preço por token</div>
          <div style={{fontSize: 76, fontWeight: 700, letterSpacing: '-0.04em', marginTop: 16, lineHeight: 1.05}}>
            $10 entrada.
            <br />
            $50 saída.
          </div>
          <div style={{fontSize: 36, fontWeight: 500, color: C.sub, marginTop: 16}}>Igual para os dois, por milhão de tokens.</div>
        </div>
      </Rise>
      <div style={{...cardStyle, marginTop: 40, opacity: card2, transform: `translateY(${(1 - card2) * 80}px)`}}>
        <div style={{fontSize: 30, fontWeight: 600, color: C.sub, textTransform: 'uppercase', letterSpacing: '0.08em'}}>Custo por tarefa</div>
        <div style={{fontSize: 60, fontWeight: 700, letterSpacing: '-0.035em', marginTop: 16, lineHeight: 1.08}}>
          Mesma nota, Astra gasta menos da metade.
        </div>
        {[
          {n: 'Fable 5.1', v: 7.63, c: C.claude, m: <ClaudeMark size={44} />, at: 84},
          {n: 'GPT-6 Astra', v: 3.26, c: C.gpt, m: <GptMark size={42} />, at: 90},
        ].map((r) => (
          <div key={r.n} style={{display: 'flex', alignItems: 'center', gap: 20, marginTop: 34}}>
            {r.m}
            <div style={{flex: 1, height: 30, borderRadius: 15, background: C.track, overflow: 'hidden'}}>
              <div style={{width: `${(bar(r.at, r.v) / 8) * 100}%`, height: '100%', background: r.c, borderRadius: 15}} />
            </div>
            <div style={{width: 200, textAlign: 'right', fontSize: 60, fontWeight: 700, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums'}}>
              ${fmt(bar(r.at, r.v), 2)}
            </div>
          </div>
        ))}
      </div>
    </AbsoluteFill>
  );
};

const Outro: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const marks = spring({frame: frame - 84, fps, config: {damping: 200}, durationInFrames: 36});
  const fade = interpolate(frame, [S.outro[1] - 14, S.outro[1]], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{justifyContent: 'center', padding: '0 96px', opacity: fade}}>
      <Rise delay={0}>
        <div style={{fontSize: 96, fontWeight: 700, letterSpacing: '-0.04em', lineHeight: 1.04, color: C.sub}}>
          Não existe o melhor modelo.
        </div>
      </Rise>
      <Rise delay={28}>
        <div style={{fontSize: 96, fontWeight: 700, letterSpacing: '-0.04em', lineHeight: 1.04, marginTop: 28}}>
          Existe o melhor para a sua tarefa.
        </div>
      </Rise>
      <div style={{display: 'flex', gap: 36, marginTop: 110, alignItems: 'center'}}>
        <ClaudeMark size={96} t={marks} />
        <div style={{fontSize: 44, fontWeight: 600, color: C.faint, opacity: marks}}>+</div>
        <GptMark size={92} t={marks} />
        <div style={{fontSize: 36, fontWeight: 600, color: C.sub, marginLeft: 16, opacity: marks, lineHeight: 1.2}}>
          Teste os dois
          <br />
          no seu trabalho.
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Sources: React.FC = () => {
  const frame = useCurrentFrame();
  const v = interpolate(frame, [S.bench[0], S.bench[0] + 12, S.outro[0] + S.outro[1] - 14, TOTAL], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const dark = frame >= S.tie[0] && frame < S.tie[0] + S.tie[1];
  let text = 'Fontes: tabela oficial do GPT-6 Astra (OpenAI) · HLE: Vellum. Valores divulgados pelos fabricantes.';
  if (frame >= S.tie[0]) text = 'Fonte: Artificial Analysis, “Benchmarking GPT-6 Astra”, set. 2026.';
  if (frame >= S.price[0] + 66) text = 'Fontes: OpenAI, Anthropic · custo por tarefa: Artificial Analysis, set. 2026.';
  if (frame >= S.outro[0]) text = 'Números de set. 2026. Benchmarks mudam; confira antes de decidir.';
  return (
    <div
      style={{
        position: 'absolute',
        bottom: 110,
        left: 96,
        right: 96,
        fontSize: 24,
        fontWeight: 500,
        color: dark ? '#636366' : C.faint,
        opacity: v,
        lineHeight: 1.35,
      }}
    >
      {text}
    </div>
  );
};

export const Benchmark: React.FC = () => {
  return (
    <AbsoluteFill style={{background: C.bg, color: C.ink, fontFamily: `${FONT}, sans-serif`}}>
      <style>{fontCss}</style>
      <Audio src={staticFile('mix.wav')} />
      <Sequence from={S.intro[0]} durationInFrames={S.intro[1]}>
        <Intro />
      </Sequence>
      <Sequence from={S.logos[0]} durationInFrames={S.logos[1]}>
        <Logos />
      </Sequence>
      <Sequence from={S.bench[0]} durationInFrames={S.bench[1]}>
        <Tally />
      </Sequence>
      {BENCH.map((b, i) => (
        <Sequence key={b.name} from={S.bench[0] + i * 75} durationInFrames={75}>
          <BenchCard b={b} i={i} />
        </Sequence>
      ))}
      <Sequence from={S.tie[0]} durationInFrames={S.tie[1]}>
        <Tie />
      </Sequence>
      <Sequence from={S.price[0]} durationInFrames={S.price[1]}>
        <Price />
      </Sequence>
      <Sequence from={S.outro[0]} durationInFrames={S.outro[1]}>
        <Outro />
      </Sequence>
      <Sources />
    </AbsoluteFill>
  );
};
