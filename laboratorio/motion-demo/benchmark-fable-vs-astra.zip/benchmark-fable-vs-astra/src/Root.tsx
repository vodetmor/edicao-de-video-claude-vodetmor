import React from 'react';
import {Composition} from 'remotion';
import {Benchmark, TOTAL} from './Benchmark';

export const Root: React.FC = () => (
  <Composition
    id="Benchmark"
    component={Benchmark}
    durationInFrames={TOTAL}
    fps={30}
    width={1080}
    height={1920}
  />
);
