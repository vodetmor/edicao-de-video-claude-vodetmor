# Demo: Fable 5.1 vs GPT-6 Astra (motion graphic estilo Apple)

Vídeo 9:16, 1080x1920, 30 s, 30 fps. Feito 100% com ferramentas gratuitas:
Remotion (animação em React), fonte Inter (licença OFL), trilha e efeitos sintetizados em Python (numpy), sem samples de terceiros.

## Roteiro (copy)
| Tempo | Tela | Texto |
|---|---|---|
| 0–2,5 s | Abertura | "Dois modelos novos. Um placar honesto." |
| 2,5–7,5 s | Logos | "Frente a frente." Fable 5.1 (Anthropic) vs GPT-6 Astra (OpenAI) |
| 7,5–17,5 s | 4 cartões + placar | Terminal-Bench 4.0 (código) 55,8 vs 57,9 · FrontierMath T4 (matemática) 87,8 vs 97,6 · Humanity's Last Exam (raciocínio) 65,0 vs 57,2 · AutomationBench (trabalho) 31,4 vs 41,4. Placar final 1 × 3 |
| 17,5–20 s | Capítulo escuro | "Índice de Inteligência 53 = 53. Empate." |
| 20–25 s | Preço | "$10 entrada, $50 saída, igual para os dois." "Mesma nota, Astra gasta menos da metade": $7,63 vs $3,26 por tarefa |
| 25–30 s | Fechamento | "Não existe o melhor modelo. Existe o melhor para a sua tarefa. Teste os dois no seu trabalho." |

## Fontes dos números (setembro de 2026)
- Tabela oficial do GPT-6 Astra (OpenAI, que compara com o Fable 5.1): https://openai.com/index/gpt-6-astra/
- Humanity's Last Exam: https://www.vellum.ai/blog/gpt-6-astra-benchmarks-explained
- Índice de Inteligência e custo por tarefa: https://artificialanalysis.ai/articles/benchmarking-gpt-6-astra
- Preço do Fable 5.1: https://www.datacamp.com/blog/claude-fable-5-1

Atenção: os números da OpenAI são divulgados pela própria empresa. A Artificial Analysis mediu o Terminal-Bench diferente (59% vs 52%).

## Logos
As marcas foram redesenhadas do zero de forma simplificada (asterisco laranja e roseta de 6 anéis), não são os arquivos oficiais. Para uso comercial ou anúncio, confira as regras de marca de cada empresa.

## Como rodar
```
npm install
python3 -m pip install numpy scipy
python3 audio/make_audio.py          # gera public/mix.wav (+ stems em audio/)
npx remotion studio src/index.ts     # editar ao vivo no navegador
npx remotion render src/index.ts Benchmark out/video.mp4
```
No Windows/Mac, apague a linha `setBrowserExecutable` do `remotion.config.ts` (ela aponta para o Chromium da nuvem).

## Como mexer
- Números e textos dos cartões: array `BENCH` em `src/Benchmark.tsx`.
- Cores: objeto `C` (fundo #F5F5F7, tinta #1D1D1F, laranja Claude #D97757). Sem degradê, sem brilho.
- Tempo: cada cena dura múltiplos de 75 quadros (1 compasso a 96 BPM), então os cortes caem no tempo forte da música. Se mudar a duração de uma cena, ajuste os tempos dos efeitos em `audio/make_audio.py`.
